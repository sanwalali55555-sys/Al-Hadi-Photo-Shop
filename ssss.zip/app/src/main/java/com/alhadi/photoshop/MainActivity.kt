package com.alhadi.photoshop

import android.content.ContentValues
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.Tasks
import com.google.android.material.button.MaterialButton
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

private enum class Panel { NONE, CROP, FILTER, BRIGHT }

private class Snapshot(val bmp: Bitmap, val transparent: Boolean)

class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var progress: ProgressBar
    private lateinit var hint: TextView
    private lateinit var optionsPanel: LinearLayout
    private lateinit var seekBrightness: SeekBar
    private lateinit var filterScroll: HorizontalScrollView
    private lateinit var filterRow: LinearLayout
    private lateinit var cropScroll: HorizontalScrollView
    private lateinit var cropRow: LinearLayout
    private lateinit var btnFaceLock: MaterialButton

    private val worker = Executors.newSingleThreadExecutor()
    private var busy = false
    private var generation = 0

    private var base: Bitmap? = null
    private var shown: Bitmap? = null
    private val undoStack = ArrayDeque<Snapshot>()
    private var filterIdx = 0
    private var brightness = 100
    private var faceLock = true
    private var transparent = false
    private var currentPanel = Panel.NONE

    @Volatile
    private var faceCache: Pair<Bitmap, List<Rect>>? = null

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) loadPhoto(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.imageView)
        progress = findViewById(R.id.progress)
        hint = findViewById(R.id.tvHint)
        optionsPanel = findViewById(R.id.optionsPanel)
        seekBrightness = findViewById(R.id.seekBrightness)
        filterScroll = findViewById(R.id.filterScroll)
        filterRow = findViewById(R.id.filterRow)
        cropScroll = findViewById(R.id.cropScroll)
        cropRow = findViewById(R.id.cropRow)
        btnFaceLock = findViewById(R.id.btnFaceLock)

        findViewById<View>(R.id.btnGallery).setOnClickListener { openGallery() }
        findViewById<View>(R.id.btnSave).setOnClickListener { save() }
        findViewById<View>(R.id.btnCrop).setOnClickListener { showPanel(Panel.CROP) }
        findViewById<View>(R.id.btnFilter).setOnClickListener { showPanel(Panel.FILTER) }
        findViewById<View>(R.id.btnBrightness).setOnClickListener { showPanel(Panel.BRIGHT) }
        findViewById<View>(R.id.btnBlur).setOnClickListener { backgroundOp(false) }
        findViewById<View>(R.id.btnRemove).setOnClickListener { backgroundOp(true) }
        findViewById<View>(R.id.btnUndo).setOnClickListener { undo() }
        btnFaceLock.setOnClickListener {
            faceLock = !faceLock
            updateFaceLockButton()
            refresh()
        }

        buildFilterRow()
        buildCropRow()
        updateFaceLockButton()

        seekBrightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    brightness = p
                    refresh()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // Open the gallery straight away
        if (savedInstanceState == null) openGallery()
    }

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }

    // ---------- UI helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(id: Int) = Toast.makeText(this, id, Toast.LENGTH_LONG).show()

    private fun setBusy(v: Boolean) {
        busy = v
        progress.visibility = if (v) View.VISIBLE else View.GONE
    }

    private fun updateFaceLockButton() {
        btnFaceLock.setText(if (faceLock) R.string.btn_facelock_on else R.string.btn_facelock_off)
    }

    private fun optionButton(label: String, onClick: () -> Unit): MaterialButton {
        val b = MaterialButton(this)
        b.text = label
        b.textSize = 15f
        b.isAllCaps = false
        b.maxLines = 2
        b.minimumHeight = dp(64)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.marginEnd = dp(6)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun buildFilterRow() {
        val names = resources.getStringArray(R.array.filter_names)
        names.forEachIndexed { i, name ->
            filterRow.addView(optionButton(name) {
                if (base != null) {
                    filterIdx = i
                    refresh()
                }
            })
        }
    }

    private fun buildCropRow() {
        val ratios = listOf(1 to 1, 4 to 3, 3 to 4, 16 to 9, 9 to 16)
        ratios.forEach { (w, h) ->
            cropRow.addView(optionButton("$w:$h") {
                runStructural { src -> centerCrop(src, w, h) }
            })
        }
        cropRow.addView(optionButton(getString(R.string.btn_rotate)) {
            runStructural { src ->
                val m = Matrix()
                m.postRotate(90f)
                Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
            }
        })
    }

    private fun showPanel(p: Panel) {
        if (base == null) {
            toast(R.string.hint_pick)
            return
        }
        currentPanel = if (currentPanel == p) Panel.NONE else p
        optionsPanel.visibility = if (currentPanel == Panel.NONE) View.GONE else View.VISIBLE
        cropScroll.visibility = if (currentPanel == Panel.CROP) View.VISIBLE else View.GONE
        filterScroll.visibility = if (currentPanel == Panel.FILTER) View.VISIBLE else View.GONE
        seekBrightness.visibility = if (currentPanel == Panel.BRIGHT) View.VISIBLE else View.GONE
    }

    private fun openGallery() {
        pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    // ---------- Loading, undo, saving ----------

    private fun loadPhoto(uri: Uri) {
        setBusy(true)
        worker.execute {
            val bmp = try {
                decode(uri)
            } catch (e: Throwable) {
                null
            }
            runOnUiThread {
                setBusy(false)
                if (bmp == null) {
                    toast(R.string.msg_error)
                } else {
                    generation++
                    undoStack.clear()
                    base = bmp
                    shown = bmp
                    transparent = false
                    faceCache = null
                    filterIdx = 0
                    brightness = 100
                    seekBrightness.progress = 100
                    imageView.setImageBitmap(bmp)
                    hint.visibility = View.GONE
                }
            }
        }
    }

    private fun decode(uri: Uri): Bitmap {
        val source = ImageDecoder.createSource(contentResolver, uri)
        return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val big = max(info.size.width, info.size.height)
            if (big > MAX_SIDE) {
                val s = MAX_SIDE.toFloat() / big
                decoder.setTargetSize(
                    max(1, (info.size.width * s).toInt()),
                    max(1, (info.size.height * s).toInt())
                )
            }
        }
    }

    private fun undo() {
        if (base == null) return
        if (filterIdx != 0 || brightness != 100) {
            filterIdx = 0
            brightness = 100
            seekBrightness.progress = 100
            refresh()
            return
        }
        val s = undoStack.removeLastOrNull() ?: return
        generation++
        base = s.bmp
        shown = s.bmp
        transparent = s.transparent
        faceCache = null
        imageView.setImageBitmap(s.bmp)
    }

    private fun save() {
        val b = shown ?: base
        if (b == null) {
            toast(R.string.hint_pick)
            return
        }
        if (busy) return
        setBusy(true)
        val asPng = transparent
        worker.execute {
            val ok = try {
                saveToGallery(b, asPng)
            } catch (e: Throwable) {
                false
            }
            runOnUiThread {
                setBusy(false)
                toast(if (ok) R.string.msg_saved else R.string.msg_error)
            }
        }
    }

    private fun saveToGallery(bmp: Bitmap, asPng: Boolean): Boolean {
        val name = "AlHadi_" + System.currentTimeMillis()
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name + if (asPng) ".png" else ".jpg")
            put(MediaStore.Images.Media.MIME_TYPE, if (asPng) "image/png" else "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AlHadiPhotoShop")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        val written = contentResolver.openOutputStream(uri)?.use { out ->
            if (asPng) bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            else bmp.compress(Bitmap.CompressFormat.JPEG, 95, out)
        } ?: false
        val done = ContentValues()
        done.put(MediaStore.Images.Media.IS_PENDING, 0)
        contentResolver.update(uri, done, null, null)
        return written
    }

    // ---------- Editing pipeline ----------

    /** Re-draws the base photo with the current filter / brightness (and Face Lock). */
    private fun refresh() {
        val b = base ?: return
        val gen = ++generation
        val f = filterIdx
        val br = brightness
        val lock = faceLock
        worker.execute {
            val result = try {
                render(b, f, br, lock)
            } catch (e: Throwable) {
                null
            }
            runOnUiThread {
                if (gen == generation && result != null) {
                    shown = result
                    imageView.setImageBitmap(result)
                }
            }
        }
    }

    /** Runs a heavy edit (crop, rotate, blur BG, remove BG) and makes the result the new base. */
    private fun runStructural(makesTransparent: Boolean = false, op: (Bitmap) -> Bitmap?) {
        val b = base
        if (b == null) {
            toast(R.string.hint_pick)
            return
        }
        if (busy) return
        setBusy(true)
        val f = filterIdx
        val br = brightness
        val lock = faceLock
        worker.execute {
            var result: Bitmap? = null
            var failed = false
            try {
                val src = render(b, f, br, lock)
                result = op(src)
            } catch (e: Throwable) {
                failed = true
            }
            val res = result
            val didFail = failed
            runOnUiThread {
                setBusy(false)
                if (res != null) {
                    commitBase(res, makesTransparent)
                } else {
                    toast(if (didFail) R.string.msg_error else R.string.msg_no_person)
                }
            }
        }
    }

    private fun commitBase(newBase: Bitmap, makesTransparent: Boolean) {
        generation++
        base?.let { undoStack.addLast(Snapshot(it, transparent)) }
        if (undoStack.size > 4) undoStack.removeFirst()
        base = newBase
        shown = newBase
        if (makesTransparent) transparent = true
        filterIdx = 0
        brightness = 100
        seekBrightness.progress = 100
        faceCache = null
        imageView.setImageBitmap(newBase)
    }

    private fun backgroundOp(remove: Boolean) {
        runStructural(remove) { src ->
            val mask = personMask(src)
            if (mask == null) null
            else if (remove) cutOut(src, mask)
            else blurBackground(src, mask)
        }
    }

    private fun render(b: Bitmap, f: Int, br: Int, lock: Boolean): Bitmap {
        if (f == 0 && br == 100) return b
        val adjusted = applyAdjustments(b, f, br)
        if (!lock) return adjusted
        val faces = facesFor(b)
        if (faces.isNotEmpty()) lockFaces(adjusted, b, faces)
        return adjusted
    }

    private fun filterMatrix(i: Int): ColorMatrix? = when (i) {
        1 -> ColorMatrix().apply { setSaturation(0f) }
        2 -> ColorMatrix(floatArrayOf(
            0.393f, 0.769f, 0.189f, 0f, 0f,
            0.349f, 0.686f, 0.168f, 0f, 0f,
            0.272f, 0.534f, 0.131f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f))
        3 -> ColorMatrix(floatArrayOf(
            1.1f, 0f, 0f, 0f, 8f,
            0f, 1f, 0f, 0f, 0f,
            0f, 0f, 0.9f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f))
        4 -> ColorMatrix(floatArrayOf(
            0.9f, 0f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f, 0f,
            0f, 0f, 1.1f, 0f, 8f,
            0f, 0f, 0f, 1f, 0f))
        5 -> ColorMatrix().apply { setSaturation(1.4f) }
        6 -> ColorMatrix(floatArrayOf(
            0.85f, 0f, 0f, 0f, 25f,
            0f, 0.85f, 0f, 0f, 25f,
            0f, 0f, 0.85f, 0f, 25f,
            0f, 0f, 0f, 1f, 0f))
        else -> null
    }

    private fun applyAdjustments(src: Bitmap, f: Int, br: Int): Bitmap {
        val cm = ColorMatrix()
        filterMatrix(f)?.let { cm.postConcat(it) }
        val d = (br - 100) * 0.8f
        cm.postConcat(ColorMatrix(floatArrayOf(
            1f, 0f, 0f, 0f, d,
            0f, 1f, 0f, 0f, d,
            0f, 0f, 1f, 0f, d,
            0f, 0f, 0f, 1f, 0f)))
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.colorFilter = ColorMatrixColorFilter(cm)
        Canvas(out).drawBitmap(src, 0f, 0f, p)
        return out
    }

    private fun centerCrop(src: Bitmap, rw: Int, rh: Int): Bitmap {
        val target = rw.toFloat() / rh
        val current = src.width.toFloat() / src.height
        val w: Int
        val h: Int
        if (current > target) {
            h = src.height
            w = max(1, (src.height * target).toInt())
        } else {
            w = src.width
            h = max(1, (src.width / target).toInt())
        }
        val x = (src.width - w) / 2
        val y = (src.height - h) / 2
        return Bitmap.createBitmap(src, x, y, w, h)
    }

    // ---------- Face Lock (original face pixels are put back after edits) ----------

    private fun facesFor(b: Bitmap): List<Rect> {
        faceCache?.let { if (it.first === b) return it.second }
        val faces = detectFaces(b)
        faceCache = Pair(b, faces)
        return faces
    }

    private fun detectFaces(bmp: Bitmap): List<Rect> {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .build()
        val detector = FaceDetection.getClient(options)
        return try {
            val faces = Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0)))
            faces.map { it.boundingBox }
        } catch (e: Throwable) {
            emptyList()
        } finally {
            detector.close()
        }
    }

    /** Draws the untouched face areas of [orig] back onto [target] with soft edges. */
    private fun lockFaces(target: Bitmap, orig: Bitmap, faces: List<Rect>) {
        val canvas = Canvas(target)
        for (f in faces) {
            val padX = (f.width() * 0.2f).toInt()
            val padY = (f.height() * 0.2f).toInt()
            val l = max(0, f.left - padX)
            val t = max(0, f.top - padY)
            val r = min(orig.width, f.right + padX)
            val b = min(orig.height, f.bottom + padY)
            val w = r - l
            val h = b - t
            if (w < 8 || h < 8) continue
            val piece = Bitmap.createBitmap(orig, l, t, w, h).copy(Bitmap.Config.ARGB_8888, true)
            val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val feather = min(w, h) * 0.12f
            val mp = Paint(Paint.ANTI_ALIAS_FLAG)
            mp.color = Color.WHITE
            mp.maskFilter = BlurMaskFilter(feather, BlurMaskFilter.Blur.NORMAL)
            Canvas(mask).drawOval(
                RectF(feather * 1.5f, feather * 1.5f, w - feather * 1.5f, h - feather * 1.5f), mp
            )
            val cut = Paint()
            cut.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            Canvas(piece).drawBitmap(mask, 0f, 0f, cut)
            canvas.drawBitmap(piece, l.toFloat(), t.toFloat(), null)
        }
    }

    // ---------- Person segmentation (background blur / remove) ----------

    /** Returns a bitmap whose alpha channel is 1 on the person and 0 on the background. */
    private fun personMask(bmp: Bitmap): Bitmap? {
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .build()
        val segmenter = Segmentation.getClient(options)
        try {
            val mask = Tasks.await(segmenter.process(InputImage.fromBitmap(bmp, 0)))
            val w = mask.width
            val h = mask.height
            val buf = mask.buffer
            buf.rewind()
            val px = IntArray(w * h)
            var strong = 0
            for (i in px.indices) {
                val conf = buf.getFloat()
                val a = ((conf - 0.3f) / 0.4f).coerceIn(0f, 1f)
                val a8 = (a * 255).toInt()
                if (a8 > 128) strong++
                px[i] = a8 shl 24
            }
            if (strong < px.size / 200) return null
            val m = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            m.setPixels(px, 0, w, 0, 0, w, h)
            return if (w == bmp.width && h == bmp.height) m
            else Bitmap.createScaledBitmap(m, bmp.width, bmp.height, true)
        } finally {
            segmenter.close()
        }
    }

    private fun cutOut(src: Bitmap, mask: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(src, 0f, 0f, null)
        val p = Paint()
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        c.drawBitmap(mask, 0f, 0f, p)
        return out
    }

    private fun blurBackground(src: Bitmap, mask: Bitmap): Bitmap {
        val blurred = softBlur(src)
        val person = cutOut(src, mask)
        Canvas(blurred).drawBitmap(person, 0f, 0f, null)
        return blurred
    }

    private fun softBlur(src: Bitmap): Bitmap {
        var small = src
        var w = src.width
        var h = src.height
        repeat(4) {
            w = max(8, w / 2)
            h = max(8, h / 2)
            small = Bitmap.createScaledBitmap(small, w, h, true)
        }
        val up = Bitmap.createScaledBitmap(small, src.width, src.height, true)
        return up.copy(Bitmap.Config.ARGB_8888, true)
    }

    companion object {
        private const val MAX_SIDE = 2048
    }
}
